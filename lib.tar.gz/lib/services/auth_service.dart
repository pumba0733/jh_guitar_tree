// lib/services/auth_service.dart
// v1.05 | 2025-08-24 | 학생 세션 + Auth 세션 혼합, 역할 판별/라우팅 헬퍼
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/student.dart';
import 'student_service.dart';
import 'teacher_service.dart';
import '../routes/app_routes.dart';

enum UserRole { student, teacher, admin }

class AuthService {
  static final AuthService _i = AuthService._internal();
  factory AuthService() => _i;
  AuthService._internal();

  final SupabaseClient _client = Supabase.instance.client;

  /// 학생 세션(간편 로그인): 앱 내 임시 상태로만 유지
  final ValueNotifier<Student?> currentStudent = ValueNotifier<Student?>(null);

  /// 교사/관리자: Supabase Auth 세션 사용
  User? get currentAuthUser => _client.auth.currentUser;

  bool get isLoggedInAsStudent => currentStudent.value != null;
  bool get isLoggedInAsAuthUser => currentAuthUser != null;

  /// 이메일/비밀번호 로그인 (교사/관리자)
  Future<AuthResponse> loginWithEmailPassword({
    required String email,
    required String password,
  }) {
    return _client.auth.signInWithPassword(email: email, password: password);
  }

  /// 학생 간편 로그인: name + last4
  Future<bool> loginStudent({
    required String name,
    required String last4,
  }) async {
    final service = StudentService();
    final s = await service.findByNameAndLast4(name: name, last4: last4);
    currentStudent.value = s;
    return s != null;
  }

  /// 로그아웃 (학생/교사/관리자 모두)
  Future<void> logoutAll() async {
    currentStudent.value = null; // 학생 세션 클리어
    try {
      await _client.auth.signOut(); // Supabase 세션 클리어
    } catch (_) {
      // 무시: 네트워크 이슈가 있어도 로컬 세션은 지운다.
    }
  }

  /// ✅ 역할 판별: 학생 세션 → admin(meta) → teachers.email
  Future<UserRole> getRole() async {
    if (isLoggedInAsStudent) return UserRole.student;

    final u = currentAuthUser;
    if (u == null) {
      return UserRole.teacher; // 비정상 케이스 기본 처리
    }

    // user_metadata.role = 'admin'
    final metaRole = u.userMetadata?['role'];
    if (metaRole is String && metaRole.toLowerCase() == 'admin') {
      return UserRole.admin;
    }

    // teachers.email 정확 일치 → teacher
    final email = u.email ?? '';
    if (email.isNotEmpty) {
      final teacherService = TeacherService();
      final isTeacher = await teacherService.existsByEmail(email);
      if (isTeacher) return UserRole.teacher;
    }

    // 기본값
    return UserRole.teacher;
  }

  /// ✅ 로그인 직후 역할에 따라 홈으로 이동하는 헬퍼
  Future<void> routeAfterLogin(BuildContext context) async {
    final role = await getRole();
    String target = AppRoutes.studentHome;
    if (role == UserRole.teacher) target = AppRoutes.teacherHome;
    if (role == UserRole.admin) target = AppRoutes.adminHome;

    if (!context.mounted) return;
    // 중복 네비 방지: 동일 라우트면 스킵
    final canPop = Navigator.of(context).canPop();
    if (canPop) {
      Navigator.of(context).pushNamedAndRemoveUntil(target, (_) => false);
    } else {
      Navigator.of(context).pushReplacementNamed(target);
    }
  }
}

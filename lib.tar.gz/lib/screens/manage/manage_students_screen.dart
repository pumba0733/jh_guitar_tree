// lib/screens/manage/manage_students_screen.dart
// v1.31.0 | 학생 관리(관리자 전용) 1차 가동본
//
// 기능:
// - 목록 조회(이름 검색) / 추가 / 수정 / 삭제
// - 관리자 전용 접근 가드 (비관리자 접근시 안내)
// - 서비스 계층(StudentService) 사용
//
// TODO(차기):
// - teacherId 드롭다운(강사 목록 연동) / 페이징 / 정렬 / 고급 필터

import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../services/student_service.dart';
import '../../models/student.dart';

class ManageStudentsScreen extends StatefulWidget {
  const ManageStudentsScreen({super.key});

  @override
  State<ManageStudentsScreen> createState() => _ManageStudentsScreenState();
}

class _ManageStudentsScreenState extends State<ManageStudentsScreen> {
  final _auth = AuthService();
  final _svc = StudentService();

  final _searchCtl = TextEditingController();
  bool _loading = true;
  bool _guarding = true;
  bool _isAdmin = false;
  String? _error;
  List<Student> _list = const [];

  @override
  void initState() {
    super.initState();
    _guardAndLoad();
  }

  Future<void> _guardAndLoad() async {
    try {
      final role = await _auth.getRole();
      _isAdmin = role == UserRole.admin;
    } catch (_) {
      _isAdmin = false;
    }
    if (!mounted) return;
    setState(() => _guarding = false);
    if (_isAdmin) _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final q = _searchCtl.text.trim();
      final data = await _svc.list(
        query: q,
        limit: 200,
        orderBy: 'created_at',
        ascending: false,
      );
      setState(() => _list = data);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _onAdd() async {
    final r = await showDialog<_EditResult>(
      context: context,
      builder: (_) => _EditStudentDialog(),
    );
    if (r == null) return;
    await _svc.create(name: r.name, phoneLast4: r.last4);
    await _load();
  }

  Future<void> _onEdit(Student s) async {
    final r = await showDialog<_EditResult>(
      context: context,
      builder: (_) =>
          _EditStudentDialog(initialName: s.name, initialLast4: s.phoneLast4),
    );
    if (r == null) return;
    await _svc.update(id: s.id, name: r.name, phoneLast4: r.last4);
    await _load();
  }

  Future<void> _onDelete(Student s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('학생 삭제'),
        content: Text('"${s.name}" 학생을 삭제할까요?\n연관 데이터가 있을 수 있습니다.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('삭제'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await _svc.remove(s.id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_guarding) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (!_isAdmin) {
      return Scaffold(
        appBar: AppBar(title: const Text('학생 관리')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.lock_outline, size: 42),
                const SizedBox(height: 8),
                const Text('관리자 전용 화면입니다.'),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back),
                  label: const Text('뒤로'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('학생 관리'),
        actions: [
          IconButton(
            tooltip: '새로고침',
            icon: const Icon(Icons.refresh),
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _onAdd,
        tooltip: '학생 추가',
        child: const Icon(Icons.person_add),
      ),
      body: Column(
        children: [
          // 검색 바
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: TextField(
              controller: _searchCtl,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _load(),
              decoration: InputDecoration(
                hintText: '이름으로 검색',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  onPressed: () {
                    _searchCtl.clear();
                    _load();
                  },
                  icon: const Icon(Icons.clear),
                  tooltip: '초기화',
                ),
                border: const OutlineInputBorder(),
              ),
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                ? _ErrorView(message: _error!, onRetry: _load)
                : _list.isEmpty
                ? _EmptyView(onRetry: _load)
                : ListView.separated(
                    padding: const EdgeInsets.all(12),
                    itemCount: _list.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final s = _list[i];
                      return ListTile(
                        leading: const Icon(Icons.person),
                        title: Text(s.name),
                        subtitle: Text(
                          [
                            if (s.phoneLast4.trim().isNotEmpty)
                              '전화 뒷자리: ${s.phoneLast4}',
                            if ((s.teacherId ?? '').trim().isNotEmpty)
                              '담당강사: ${s.teacherId}',
                            if (s.createdAt != null)
                              '등록: ${s.createdAt!.toIso8601String().split("T").first}',
                          ].join(' · '),
                        ),
                        trailing: Wrap(
                          spacing: 4,
                          children: [
                            IconButton(
                              tooltip: '수정',
                              icon: const Icon(Icons.edit),
                              onPressed: () => _onEdit(s),
                            ),
                            IconButton(
                              tooltip: '삭제',
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () => _onDelete(s),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _EmptyView extends StatelessWidget {
  final Future<void> Function() onRetry;
  const _EmptyView({required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.inbox, size: 42),
            const SizedBox(height: 8),
            const Text('등록된 학생이 없습니다.'),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('새로고침'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final Future<void> Function() onRetry;
  const _ErrorView({required this.message, required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 42),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('다시 시도'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------- 학생 추가/수정 다이얼로그 ----------
class _EditResult {
  final String name;
  final String last4;
  const _EditResult(this.name, this.last4);
}

class _EditStudentDialog extends StatefulWidget {
  final String? initialName;
  final String? initialLast4;

  const _EditStudentDialog({this.initialName, this.initialLast4});

  @override
  State<_EditStudentDialog> createState() => _EditStudentDialogState();
}

class _EditStudentDialogState extends State<_EditStudentDialog> {
  late final TextEditingController _nameCtl;
  late final TextEditingController _last4Ctl;

  @override
  void initState() {
    super.initState();
    _nameCtl = TextEditingController(text: widget.initialName ?? '');
    _last4Ctl = TextEditingController(text: widget.initialLast4 ?? '');
  }

  @override
  void dispose() {
    _nameCtl.dispose();
    _last4Ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = (widget.initialName ?? '').isNotEmpty;

    return AlertDialog(
      title: Text(isEdit ? '학생 정보 수정' : '학생 추가'),
      content: SizedBox(
        width: 420,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameCtl,
              autofocus: true,
              decoration: const InputDecoration(
                labelText: '이름',
                hintText: '예: 홍길동',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _last4Ctl,
              maxLength: 4,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: '전화 뒷자리 4',
                hintText: '예: 1234',
                counterText: '',
              ),
            ),
            const SizedBox(height: 4),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '※ 학생 인증(RPC)에도 사용됩니다. 정확히 입력하세요.',
                style: TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('취소'),
        ),
        FilledButton(
          onPressed: () {
            final name = _nameCtl.text.trim();
            final l4 = _last4Ctl.text.trim();
            if (name.isEmpty) return;
            if (l4.isNotEmpty && l4.length != 4) return;
            Navigator.pop(context, _EditResult(name, l4));
          },
          child: Text(isEdit ? '저장' : '추가'),
        ),
      ],
    );
  }
}

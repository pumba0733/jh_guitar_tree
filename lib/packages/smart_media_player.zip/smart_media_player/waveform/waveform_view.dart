// smart_media_player/waveform/waveform_view.dart
// v3.30.1-hotfix | robust guards for empty/width/length + minLen sync + withOpacity

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'waveform_tuning.dart';

enum WaveDrawMode { auto, bars, candles, path }

class WaveformView extends StatefulWidget {
  // ── 기본 데이터(기존 호환)
  final List<double> peaks; // 0..1 abs
  final List<double>? peaksRight; // 0..1 abs (optional)
  final Duration duration;
  final Duration position;
  final Duration? loopA;
  final Duration? loopB;
  final bool loopOn;
  final List<Duration> markers;
  final List<String>? markerLabels;
  final List<Color?>? markerColors;

  // 뷰포트
  final double viewStart; // 0..1 (raw 입력, 클램프는 State에서)
  final double viewWidth; // 0..1 (raw 입력, 클램프는 State에서)

  // 선택/탐색
  final bool selectionMode;
  final Duration? selectionA;
  final Duration? selectionB;
  final ValueChanged<Duration>? onSeek;
  final ValueChanged<Duration>? onSelectStart;
  final ValueChanged<Duration>? onSelectUpdate;
  final void Function(Duration? a, Duration? b)? onSelectEnd;

  // 시각 옵션
  final bool dualLayer; // Fill + Stroke
  final bool useSignedAmplitude; // Stroke에 부호(±) 반영
  final bool splitStereoQuadrants; // 스테레오 분리
  final WaveDrawMode drawMode;

  // 추가 입력(기존 + 확장)
  final List<double>? rmsLeft; // 0..1
  final List<double>? rmsRight; // 0..1
  final List<double>? signedLeft; // -1..+1
  final List<double>? signedRight; // -1..+1

  // NEW: FFTW 밴드 에너지(가중합) – 있으면 Fill에 우선 사용
  final List<double>? bandEnergyLeft; // 0..1
  final List<double>? bandEnergyRight; // 0..1

  // 매핑 제어
  final bool visualExact; // true면 dB/감마/오토게인 미사용
  final bool preferTuningFlags; // true면 파라미터를 Tuning 전역값 우선

  const WaveformView({
    super.key,
    required this.peaks,
    this.peaksRight,
    required this.duration,
    required this.position,
    this.loopA,
    this.loopB,
    this.loopOn = false,
    this.markers = const [],
    this.markerLabels,
    this.markerColors,
    required this.viewStart,
    required this.viewWidth,
    this.selectionMode = false,
    this.selectionA,
    this.selectionB,
    this.onSeek,
    this.onSelectStart,
    this.onSelectUpdate,
    this.onSelectEnd,
    // 시각 기본
    this.dualLayer = true,
    this.useSignedAmplitude = true,
    this.splitStereoQuadrants = true,
    this.drawMode = WaveDrawMode.auto,
    // 추가 입력
    this.rmsLeft,
    this.rmsRight,
    this.signedLeft,
    this.signedRight,
    // NEW
    this.bandEnergyLeft,
    this.bandEnergyRight,
    // 매핑
    this.visualExact = false,
    this.preferTuningFlags = true,
  });

  @override
  State<WaveformView> createState() => _WaveformViewState();
}

class _WaveformViewState extends State<WaveformView> {
  double get _vw {
    final w = widget.viewWidth;
    return (w.isNaN || !w.isFinite) ? 1.0 : w.clamp(0.001, 1.0);
  }

  double get _vs {
    final s = widget.viewStart;
    final maxStart = 1.0 - _vw;
    return (s.isNaN || !s.isFinite) ? 0.0 : s.clamp(0.0, maxStart);
  }

  @override
  void initState() {
    super.initState();
    WaveformTuning.I.addListener(_onToneChanged);
  }

  @override
  void dispose() {
    WaveformTuning.I.removeListener(_onToneChanged);
    super.dispose();
  }

  void _onToneChanged() {
    if (!mounted) return;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        isComplex: true,
        willChange: true,
        painter: _WavePainter(
          // 데이터
          peaksL: widget.peaks,
          peaksR: widget.peaksRight,
          rmsL: widget.rmsLeft,
          rmsR: widget.rmsRight,
          signedL: widget.signedLeft,
          signedR: widget.signedRight,
          // NEW: 밴드 에너지
          bandL: widget.bandEnergyLeft,
          bandR: widget.bandEnergyRight,
          // 타임라인
          duration: widget.duration,
          position: widget.position,
          loopA: widget.loopA,
          loopB: widget.loopB,
          loopOn: widget.loopOn,
          markers: widget.markers,
          markerLabels: widget.markerLabels,
          markerColors: widget.markerColors,
          // 뷰포트
          viewStart: _vs,
          viewWidth: _vw,
          // 옵션
          dualLayer: widget.dualLayer,
          useSignedAmplitude: widget.useSignedAmplitude,
          splitStereoQuadrants: widget.splitStereoQuadrants,
          drawMode: widget.drawMode,
          visualExact: widget.visualExact,
          // repaint link
          repaintListenable: WaveformTuning.I,
        ),
        child: const SizedBox.expand(),
      ),
    );
  }
}

enum _DownsampleMode { mean, maxAbs }

class _WavePainter extends CustomPainter {
  static bool _loggedOnce = false;
  final List<double> peaksL;
  final List<double>? peaksR;
  final List<double>? rmsL;
  final List<double>? rmsR;
  final List<double>? signedL;
  final List<double>? signedR;
  // NEW
  final List<double>? bandL;
  final List<double>? bandR;

  final Duration duration;
  final Duration position;
  final Duration? loopA;
  final Duration? loopB;
  final bool loopOn;
  final List<Duration> markers;
  final List<String>? markerLabels;
  final List<Color?>? markerColors;

  final double viewStart;
  final double viewWidth;

  final bool dualLayer;
  final bool useSignedAmplitude;
  final bool splitStereoQuadrants;
  final WaveDrawMode drawMode;
  final bool visualExact;

  _WavePainter({
    required this.peaksL,
    required this.peaksR,
    required this.rmsL,
    required this.rmsR,
    required this.signedL,
    required this.signedR,
    required this.bandL,
    required this.bandR,
    required this.duration,
    required this.position,
    required this.loopA,
    required this.loopB,
    required this.loopOn,
    required this.markers,
    required this.markerLabels,
    required this.markerColors,
    required this.viewStart,
    required this.viewWidth,
    required this.dualLayer,
    required this.useSignedAmplitude,
    required this.splitStereoQuadrants,
    required this.drawMode,
    required this.visualExact,
    Listenable? repaintListenable,
  }) : super(repaint: repaintListenable);

  @override
  void paint(Canvas canvas, Size size) {
    final t = WaveformTuning.I;

    // 🚧 size 0 가드: 레이아웃 미완 상태면 조용히 리턴
    if (size.width <= 0 || size.height <= 0) {
      return;
    }

    // 배경
    final Paint bg = Paint()..color = t.bgColor;
    canvas.drawRect(Offset.zero & size, bg);

    // ✅ clip rect (헤어라인 방지)
    final double w = size.width <= 0 ? 1.0 : size.width;
    final double h = size.height <= 1 ? 1.0 : size.height;
    final Rect rect = Rect.fromLTWH(0.0, 0.5, w, h - 1.0);

    canvas.save();
    canvas.clipRect(rect);

    // L/R 한 줄 혹은 쿼드런트
    if (splitStereoQuadrants && peaksR != null && (peaksR!.isNotEmpty)) {
      final double half = rect.height / 2;
      final upper = Rect.fromLTWH(rect.left, rect.top, rect.width, half);
      final lower = Rect.fromLTWH(rect.left, rect.top + half, rect.width, half);
      _paintOne(canvas, upper, left: true, t: t);
      _paintOne(canvas, lower, left: false, t: t);
    } else {
      _paintOne(canvas, rect, left: true, t: t);
    }

    // 오버레이(루프/플레이헤드/마커)도 같은 clip 안에서 그리기
    _paintLoopFill(canvas, rect, t);
    _paintPlayhead(canvas, rect, t);
    _paintMarkers(canvas, rect, t);

    canvas.restore();
  }
    
    void _paintOne(
    Canvas canvas,
    Rect rect, {
    required bool left,
    required WaveformTuning t,
  }) {
    final srcPeaks = left ? peaksL : (peaksR ?? peaksL);
    final srcRms = left ? rmsL : (rmsR ?? rmsL);
    final srcBand = left ? bandL : bandR;
    final srcSigned = left ? signedL : signedR;

      // 1) 기준 시퀀스 고르기 (없으면 리턴)
  late final List<double> refSrc;
  if (srcPeaks.isNotEmpty) {
    refSrc = srcPeaks;
  } else if (srcBand != null && srcBand.isNotEmpty) {
    refSrc = srcBand;
  } else if (srcRms != null && srcRms.isNotEmpty) {
    refSrc = srcRms; // <- '!' 제거
  } else {
    return;
  }

  final int srcN = refSrc.length;
  if (srcN <= 0) return;


    if (!_loggedOnce) {
      final ms = duration.inMilliseconds;
      final binMs = ms / math.max(1, srcN - 1);
      debugPrint(
        '[WAVE] painter left=$left '
        'durMs=$ms srcN=$srcN bin≈${binMs.toStringAsFixed(3)}ms '
        'viewStart=${viewStart.toStringAsFixed(3)} viewWidth=${viewWidth.toStringAsFixed(3)} '
        'peaksN=${peaksL.length} rmsN=${rmsL?.length ?? 0} bandN=${bandL?.length ?? 0}',
      );
      _loggedOnce = true;
    }
    // 2) "픽셀 주도형" 렌더: 화면 가로 픽셀 수만큼 샘플 생성
    final double wpx = rect.width <= 0 ? 1.0 : rect.width;
    final int px = wpx.floor().clamp(1, 1000000); // ▶ 우측 경계 과샘플링 방지
    final double vs = viewStart; // 0..1
    final double vw = (viewWidth <= 0) ? 1.0 : viewWidth; // 0..1

    // refSrc에서 시간비율 u(0..1)에 해당하는 샘플을 읽는 함수
    double sampleAt(List<double> src, double u) {
      if (src.isEmpty) return 0.0;
      if (u.isNaN || !u.isFinite) u = 0.0;
      if (u <= 0) return _san(src.first);
      if (u >= 1) return _san(src.last); // ✅ 끝은 마지막 샘플
      // ⚙️ 비율 계산을 duration 기반으로 정규화
      final double f = u * (src.length - 1);
      final int a = f.floor();
      final int b = (a + 1).clamp(0, src.length - 1);
      final double w = f - a;
      final double va = _san(src[a]);
      final double vb = _san(src[b]);
      final double interp = va * (1 - w) + vb * w;
      return _clamp01(interp);
    }


    // Fill(밴드/RMS), Stroke(피크/부호)용 픽셀 배열 만들기
    final List<double> fillSrcPx = List<double>.generate(px, (i) {
      final double xFrac = ((i + 0.5) / px).clamp(0.0, 1.0 - 1e-9);
      final double u = (vs + xFrac * vw).clamp(0.0, 1.0);
      final List<double>? pref = (srcBand != null && srcBand!.isNotEmpty)
          ? srcBand
          : (srcRms != null && srcRms!.isNotEmpty)
          ? srcRms
          : null;
      return sampleAt(pref ?? refSrc, u);
    }, growable: false);

    final List<double> peakPx = List<double>.generate(px, (i) {
      final double xFrac = i / math.max(1, px - 1);
      final double u = (vs + xFrac * vw).clamp(0.0, 1.0);
      return sampleAt(refSrc, u);
    }, growable: false);

    final List<double> signedPx = (() {
      final List<double>? s = srcSigned;
      if (useSignedAmplitude && s != null && s.isNotEmpty) {
        return List<double>.generate(px, (i) {
          final double xFrac = i / math.max(1, px - 1);
          final double u = (vs + xFrac * vw).clamp(0.0, 1.0);
          // 부호는 평균 대신 근사 보간
          final double v = sampleAt(s, u);
          return v.isNaN || !v.isFinite ? 0.0 : v.clamp(-1.0, 1.0);
        }, growable: false);
      }
      // 부호 없으면 피크에서 의사부호
      bool sign = true;
      return List<double>.generate(px, (i) {
        final double v = peakPx[i];
        final double out = sign ? v : -v;
        sign = !sign;
        return out;
      }, growable: false);
    })();

    // 3) 매핑
    double mapFn(double x) {
      if (visualExact) return _clamp01(x);
      final lv = _clamp01(x) * (1 - 1e-6) + 1e-6;
      final db = 20 * math.log(lv) / math.ln10;
      final norm = ((db - t.dbFloor) / (t.dbCeil - t.dbFloor)).clamp(0.0, 1.0);
      final g = norm <= 0.7 ? t.loudGammaLow : t.loudGammaHigh;
      return math.pow(norm, g).toDouble();
    }

    // 4) 좌표계
    final double cx = rect.left;
    final double cy = rect.top + rect.height / 2;
    final double sx = rect.width / px.toDouble(); // ▶ 픽셀 폭 기준
    double yh(double v) => (rect.height / 2) * v;

    // 5) 언더레이어 Fill
    if (dualLayer) {
      final p = Path()..moveTo(cx, cy);
      for (int i = 0; i < px; i++) {
        final double x = cx + i * sx;
        final double y = cy - yh(mapFn(fillSrcPx[i]));
        p.lineTo(x, y);
      }
      for (int i = px - 1; i >= 0; i--) {
        final double x = cx + i * sx;
        final double y = cy + yh(mapFn(fillSrcPx[i]));
        p.lineTo(x, y);
      }
      p.close();

      final baseColor = left ? t.fillColorL : t.fillColorR;
      final color = baseColor.withValues(alpha: t.fillAlpha);
      final fill = Paint()
        ..style = PaintingStyle.fill
        ..color = color
        ..isAntiAlias = true
        ..maskFilter = (t.blurSigma > 0)
            ? MaskFilter.blur(BlurStyle.normal, t.blurSigma)
            : null;
      canvas.drawPath(p, fill);
    }

    // 6) 피크/부호 Stroke
    if (t.strokeWidth > 0.0) {
      final path = Path();
      for (int i = 0; i < px; i++) {
        final double x = cx + i * sx;
        final double amp = useSignedAmplitude ? signedPx[i] : peakPx[i];
        final double y = cy - (yh(mapFn(amp.abs())) * (amp >= 0 ? 1 : -1));
        if (i == 0)
          path.moveTo(x, y);
        else
          path.lineTo(x, y);
      }
      final stroke = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = t.strokeWidth
        ..color = left ? t.strokeColorL : t.strokeColorR
        ..isAntiAlias = true;
      canvas.drawPath(path, stroke);
    }
  }


  void _paintLoopFill(Canvas canvas, Rect rect, WaveformTuning t) {
    if (!loopOn || loopA == null || loopB == null || loopA == loopB) return;
    final a = _timeToX(loopA!, rect);
    final b = _timeToX(loopB!, rect);
    final rr = RRect.fromLTRBR(
      math.min(a, b),
      rect.top,
      math.max(a, b),
      rect.bottom,
      const Radius.circular(2),
    );
    final paint = Paint()
      ..style = PaintingStyle.fill
      ..color = t.loopFill;
    canvas.drawRRect(rr, paint);
  }

  void _paintPlayhead(Canvas canvas, Rect rect, WaveformTuning t) {
    final x = _timeToX(position, rect);
    // 보정 추가
    final adjustedX = x + 0.5; // 반픽셀 정렬 + float offset 보정
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = t.playheadWidth
      ..color = t.playhead;
    canvas.drawLine(
      Offset(adjustedX, rect.top),
      Offset(adjustedX, rect.bottom),
      paint,
    );
  }


  void _paintMarkers(Canvas canvas, Rect rect, WaveformTuning t) {
    if (markers.isEmpty) return;
    for (int i = 0; i < markers.length; i++) {
      final x = _timeToX(markers[i], rect);
      canvas.drawLine(
        Offset(x, rect.top),
        Offset(x, rect.bottom),
        Paint()
          ..color = t.markerColor(i)
          ..strokeWidth = t.markerWidth,
      );
    }
  }

  // ===== Helpers =====
  static double _clamp01(double v) => v < 0 ? 0 : (v > 1 ? 1 : v);
  // NEW: NaN/Inf → 0.0 으로 정규화
  static double _san(double v) {
    if (v.isNaN || !v.isFinite) return 0.0;
    return v;
  }

  static double _sanAbs(double v) {
    final x = _san(v);
    final a = x.abs();
    return a.isNaN || !a.isFinite ? 0.0 : a;
  }

  double _loudMap(double v, WaveformTuning t) {
    final lv = _clamp01(v) * (1 - 1e-6) + 1e-6;
    final db = 20 * math.log(lv) / math.ln10;
    final norm = ((db - t.dbFloor) / (t.dbCeil - t.dbFloor)).clamp(0.0, 1.0);
    final g = norm <= 0.7 ? t.loudGammaLow : t.loudGammaHigh;
    return math.pow(norm, g).toDouble();
  }

  List<double> _downsample(
    List<double> src,
    int from,
    int to,
    int win, {
    required _DownsampleMode mode,
  }) {
    if (from >= to) return const [0.0];
    final out = <double>[];
    int i = from;
    while (i < to) {
      final int span = math.min(win, to - i);
      double accAbs = 0, maxAbs = 0;
      for (int k = 0; k < span; k++) {
        // ✅ NaN/Inf 보호
        final av = _sanAbs(src[i + k]);
        accAbs += av;
        if (av > maxAbs) maxAbs = av;
      }
      switch (mode) {
        case _DownsampleMode.mean:
          out.add(_clamp01(_san(accAbs / math.max(1, span))));
          break;
        case _DownsampleMode.maxAbs:
          out.add(_clamp01(_san(maxAbs)));
          break;
      }
      i += span;
    }
    return out.isEmpty ? const [0.0] : out;
  }


  List<double> approxRmsFromPeaks(List<double> src, int from, int to, int win) {
    if (from >= to) return const [0.0];
    final out = <double>[];
    int i = from;
    while (i < to) {
      final span = math.min(win, to - i);
      double acc2 = 0;
      for (int k = 0; k < span; k++) {
        final v = src[i + k];
        acc2 += v * v;
      }
      out.add(_clamp01(math.sqrt(acc2 / math.max(1, span))));
      i += span;
    }
    return out.isEmpty ? const [0.0] : out;
  }

  List<double> _approxSignedFromPeaks(
    List<double> src,
    int from,
    int to,
    int win,
  ) {
    if (from >= to) return const [0.0];
    final out = <double>[];
    int i = from;
    bool sign = true;
    while (i < to) {
      final span = math.min(win, to - i);
      double maxAbs = 0;
      for (int k = 0; k < span; k++) {
        final av = _sanAbs(src[i + k]);
        if (av > maxAbs) maxAbs = av;
      }
      final v = sign ? maxAbs : -maxAbs;
      out.add(_san(v));
      sign = !sign;
      i += span;
    }
    return out.isEmpty ? const [0.0] : out;
  }

  double _timeToX(Duration d, Rect rect) {
    if (duration <= Duration.zero) return rect.left;
    final double w = rect.width <= 0 ? 1.0 : rect.width;

    // (1) time → ratio (정규화)
    double t = d.inMilliseconds / duration.inMilliseconds;

    // ⚠️ 일부 mpv 버전에서 position이 duration보다 약간 커지는 경우 보호
    if (t > 1.0) t = 1.0;

    // (2) view width/start 반영
    final double vw = (viewWidth.isNaN || viewWidth <= 0) ? 1.0 : viewWidth;
    final v = ((t - viewStart) / vw).clamp(0.0, 1.0);

    // (3) rounding 보정
    final double x = rect.left + w * v;
    return x.isNaN || !x.isFinite ? rect.left : x;
  }


  @override
  bool shouldRepaint(covariant _WavePainter old) {
    return old.peaksL != peaksL ||
        old.peaksR != peaksR ||
        old.rmsL != rmsL ||
        old.rmsR != rmsR ||
        old.signedL != signedL ||
        old.signedR != signedR ||
        old.bandL != bandL ||
        old.bandR != bandR ||
        old.viewStart != viewStart ||
        old.viewWidth != viewWidth ||
        old.position != position ||
        old.loopA != loopA ||
        old.loopB != loopB ||
        old.loopOn != loopOn ||
        old.dualLayer != dualLayer ||
        old.useSignedAmplitude != useSignedAmplitude ||
        old.splitStereoQuadrants != splitStereoQuadrants ||
        old.drawMode != drawMode ||
        old.visualExact != visualExact;
  }
}

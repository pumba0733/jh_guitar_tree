// lib/constants/app_env.dart
// v1.21 LLM/운영 스위치
class AppEnv {
  static const bool isProd = false; // 필요 시 런타임 교체
  // LLM HTTP 엔드포인트(사내 프록시/Cloud Function 등으로 래핑 권장)
  static const String llmEndpoint = 'https://YOUR_LLM_ENDPOINT/summary';
  static const String llmApiKey = 'YOUR_LLM_API_KEY';
}

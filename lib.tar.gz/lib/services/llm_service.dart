// lib/services/llm_service.dart
// v1.21.2 요약 LLM 호출 — HTTP 래퍼
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_env.dart';

class LlmService {
  Future<Map<String, String>> generateFourSummaries({
    required Map<String, dynamic> studentInfo,
    required List<Map<String, dynamic>> lessons,
    required Map<String, dynamic>
    condition, // {type:'기간별'|'키워드', period_start, ...}
  }) async {
    final payload = {
      'student': studentInfo,
      'lessons': lessons,
      'condition': condition,
      'outputs': ['student', 'parent', 'blog', 'teacher'],
    };

    final uri = Uri.parse(AppEnv.llmEndpoint);
    final r = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${AppEnv.llmApiKey}',
      },
      body: jsonEncode(payload),
    );

    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('LLM 요청 실패: ${r.statusCode} ${r.body}');
    }

    final data = jsonDecode(r.body) as Map<String, dynamic>;
    return {
      'result_student': '${data['student'] ?? ''}',
      'result_parent': '${data['parent'] ?? ''}',
      'result_blog': '${data['blog'] ?? ''}',
      'result_teacher': '${data['teacher'] ?? ''}',
    };
  }
}

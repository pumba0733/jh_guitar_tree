// WaveformPanel — WaveformView 바인딩 패널 (원본 배열 그대로 전달 / 리샘플 제거)

import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:math' as math;

import '../waveform_tuning.dart';
import '../waveform_cache.dart';
import '../waveform_view.dart';
import 'waveform_system.dart';

class WaveformPanel extends StatefulWidget {
  final WaveformController controller;
  final String mediaPath;
  final String mediaHash;
  final String cacheDir;
  final VoidCallback? onStateDirty;

  const WaveformPanel({
    super.key,
    required this.controller,
    required this.mediaPath,
    required this.mediaHash,
    required this.cacheDir,
    this.onStateDirty,
  });

  @override
  State<WaveformPanel> createState() => _WaveformPanelState();
}

class _WaveformPanelState extends State<WaveformPanel> {
  List<double> _signedL = const [], _signedR = const [];
  List<double> _rmsL = const [], _rmsR = const [];
  List<double>? _bandL, _bandR;

  double _progress = 0.0;

  Future<void>? _loadFut;
  bool _postScheduled = false;

  void _postFrameEnsureLoaded() {
    if (_postScheduled) return;
    _postScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _postScheduled = false;
      if (!mounted) return;
      _ensureLoaded();
    });
  }

  @override
  void initState() {
    super.initState();
    // 초기 전체 뷰
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      widget.controller.setViewport(start: 0.0, width: 1.0);
      _postFrameEnsureLoaded();
      _ensureLoaded();
    });
  }

  @override
  void didUpdateWidget(covariant WaveformPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.mediaPath != widget.mediaPath ||
        oldWidget.mediaHash != widget.mediaHash ||
        oldWidget.cacheDir != widget.cacheDir) {
      _resetData();
      _postFrameEnsureLoaded();
    }
  }

  void _resetData() {
    setState(() {
      _signedL = const [];
      _signedR = const [];
      _rmsL = const [];
      _rmsR = const [];
      _bandL = null;
      _bandR = null;
      _progress = 0.0;
    });
  }

  void _ensureLoaded() {
    if (_loadFut != null) return;
    _loadFut = _load().whenComplete(() => _loadFut = null);
  }

  Future<void> _load() async {
    setState(() => _progress = 0.02);
    final c = widget.controller;
    final durHint = c.duration.value;

    try {
      final res = await WaveformCache.instance.loadOrBuildStereoVectors(
        mediaPath: widget.mediaPath,
        cacheDir: widget.cacheDir,
        cacheKey: widget.mediaHash,
        durationHint: durHint,
        onProgress: (p) {
          if (!mounted) return;
          final v = (p.isNaN || !p.isFinite) ? 0.0 : p.clamp(0.0, 1.0);
          if (v != _progress) setState(() => _progress = v);
        },
      );

      if (!mounted) return;
      setState(() {
        _signedL = res.signedL;
        _signedR = res.signedR;
        _rmsL = res.rmsL;
        _rmsR = res.rmsR;
        _bandL = res.bandL;
        _bandR = res.bandR;
        _progress = 1.0;
      });
      final vwNow = widget.controller.viewWidth.value;
      final vsNow = widget.controller.viewStart.value;
      // width가 0.99보다 작거나, 이전에 0길이 상태였다면 전체로 초기화
      if (vwNow < 0.99 ||
          (_rmsL.isNotEmpty && _rmsL.length > 0 && _progress == 1.0)) {
        widget.controller.setViewport(start: 0.0, width: 1.0);
      }
      debugPrint(
        '[WAVE] viewport after load: start=${widget.controller.viewStart.value.toStringAsFixed(3)} '
        'width=${widget.controller.viewWidth.value.toStringAsFixed(3)}',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('파형 생성 실패: $e')));
    }
  }

  List<Duration> _toMarkerTimes(List<dynamic> src) {
    final out = <Duration>[];
    for (final m in src) {
      try {
        if (m is Duration) {
          out.add(m);
          continue;
        }
        final d = m as dynamic;
        if (d.t is Duration) {
          out.add(d.t as Duration);
          continue;
        }
        if (d.timeMs is int) {
          out.add(Duration(milliseconds: d.timeMs as int));
          continue;
        }
        if (d.ms is int) {
          out.add(Duration(milliseconds: d.ms as int));
          continue;
        }
        if (d.positionMs is int) {
          out.add(Duration(milliseconds: d.positionMs as int));
          continue;
        }
      } catch (_) {}
      out.add(Duration.zero);
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    debugPrint(
      '[WAVE] view start=${c.viewStart.value.toStringAsFixed(3)} '
      'width=${c.viewWidth.value.toStringAsFixed(3)} ready=${((_bandL != null && _bandL!.isNotEmpty) || _rmsL.isNotEmpty)}',
    );
    debugPrint(
      '[WAVE] durMs=${c.duration.value.inMilliseconds}, '
      'rmsL=${_rmsL.length}, rmsR=${_rmsR.length}, '
      'bandL=${_bandL?.length ?? 0}, bandR=${_bandR?.length ?? 0}, '
      'signedL=${_signedL.length}, signedR=${_signedR.length}',
    );
    final bool hasBand =
        _bandL != null &&
        _bandR != null &&
        _bandL!.isNotEmpty &&
        _bandR!.isNotEmpty;
    final bool hasRms = _rmsL.isNotEmpty && _rmsR.isNotEmpty;
    final bool ready = hasBand || hasRms;

    // RMS → mono
    final List<double> monoRms = hasRms
        ? List<double>.generate(
            math.min(_rmsL.length, _rmsR.length),
            (i) => (_rmsL[i] + _rmsR[i]) * 0.5,
            growable: false,
          )
        : const <double>[];

    // Band → mono
    final List<double>? monoBand = hasBand
        ? List<double>.generate(
            math.min(_bandL!.length, _bandR!.length),
            (i) => (_bandL![i] + _bandR![i]) * 0.5,
            growable: false,
          )
        : null;

    // ✅ 리샘플 금지: 있는 그대로
    final List<double> underlay = (monoBand ?? monoRms);
    final List<double> monoPeaks = (ready && underlay.isNotEmpty)
        ? underlay
        : const <double>[];

    return AnimatedBuilder(
      animation: Listenable.merge([
        c.duration,
        c.position,
        c.viewStart,
        c.viewWidth,
        c.loopA,
        c.loopB,
        c.loopOn,
        c.markers,
        c.markerLabels,
      ]),
      builder: (context, _) {
        final dur = c.duration.value;
        final viewStart = c.viewStart.value.clamp(0.0, 1.0);
        final viewWidth = c.viewWidth.value.clamp(0.02, 1.0);
        final markerTimes = _toMarkerTimes(c.markers.value);

        if (!ready || underlay.isEmpty) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              LinearProgressIndicator(
                value: (_progress > 0 && _progress <= 1.0) ? _progress : null,
                minHeight: 2,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 12),
              const Center(child: Text('파형 로딩 중...')),
            ],
          );
        }

        // stroke 제거 + fill 강조
        WaveformTuning.I.strokeWidth = 0.0;
        WaveformTuning.I.fillAlpha = 0.6;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_progress < 1.0)
              LinearProgressIndicator(
                value: _progress,
                minHeight: 2,
                color: Theme.of(context).colorScheme.primary,
              ),
            const SizedBox(height: 6),
            SizedBox(
              height: WaveformTuning.panelHeight,
              child: GestureDetector(
                onTapDown: (d) {
                  final box = context.findRenderObject() as RenderBox?;
                  if (box == null || dur == Duration.zero) return;
                  final local = box.globalToLocal(d.globalPosition);
                  final frac = (local.dx / box.size.width).clamp(0.0, 1.0);
                  final t = _xToDuration(frac, dur, viewStart, viewWidth);
                  c.position.value = t;
                  c.setStartCue(t);
                  widget.controller.onSeek?.call(t);
                  widget.onStateDirty?.call();
                },
                child: WaveformView(
                  peaks: monoPeaks,
                  peaksRight: null,
                  duration: dur,
                  position: c.position.value,
                  loopA: c.loopA.value,
                  loopB: c.loopB.value,
                  loopOn: c.loopOn.value,
                  markers: markerTimes,
                  markerLabels: c.markerLabels.value,
                  markerColors: null,
                  viewStart: viewStart,
                  viewWidth: viewWidth,
                  selectionMode: true,
                  selectionA: c.selectionA.value,
                  selectionB: c.selectionB.value,
                  onSeek: (d) {
                    c.position.value = d;
                    c.setStartCue(d);
                    widget.controller.onSeek?.call(d);
                    widget.onStateDirty?.call();
                  },
                  onSelectStart: (a) => c.selectionA.value = a,
                  onSelectUpdate: (b) => c.selectionB.value = b,
                  onSelectEnd: (a, b) {
                    c.selectionA.value = a;
                    c.selectionB.value = b;
                    widget.onStateDirty?.call();
                  },
                  // 표시 옵션
                  useSignedAmplitude: false,
                  splitStereoQuadrants: false,
                  drawMode: WaveDrawMode.auto,
                  // 언더레이어(원본 그대로)
                  bandEnergyLeft: underlay,
                  bandEnergyRight: null,
                  rmsLeft: monoRms,
                  rmsRight: null,
                  signedLeft: const <double>[],
                  signedRight: null,
                  visualExact: true,
                  preferTuningFlags: false,
                  dualLayer: true,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Duration _xToDuration(double x, Duration total, double vs, double vw) {
    final f = (vs + x * vw).clamp(0.0, 1.0);
    final ms = (f * total.inMilliseconds).round();
    return Duration(milliseconds: ms);
  }
}

//lib/packages/smart_media_player/waveform/waveform_cache.dart
// v3.30.4 | FFmpeg/JW 경로·길이 로깅 + dev.log 사용 (no flutter import)

import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:developer' as dev;

import 'package:just_waveform/just_waveform.dart';
import 'package:path/path.dart' as p;

import 'waveform_tuning.dart';
import 'analyzer/waveform_analyzer_fftw.dart';

typedef WaveformProgressCallback = void Function(double p);

class FfmpegUnavailable implements Exception {
  final String message;
  FfmpegUnavailable(this.message);
  @override
  String toString() => 'FfmpegUnavailable: $message';
}

String? _findBundledFfmpeg() {
  try {
    if (!Platform.isMacOS) return null;
    final exeDir = File(Platform.resolvedExecutable).parent;
    final cand1 = File(p.join(exeDir.path, 'ffmpeg'));
    final cand2 = File(p.join(exeDir.parent.path, 'Frameworks', 'ffmpeg'));
    if (cand1.existsSync()) return cand1.path;
    if (cand2.existsSync()) return cand2.path;
  } catch (_) {}
  return null;
}

class WaveformLoadResult {
  final List<double> signedL; // -1..+1
  final List<double> signedR; // -1..+1
  final List<double> rmsL; // 0..1
  final List<double> rmsR; // 0..1
  final List<double>? bandL; // 0..1
  final List<double>? bandR; // 0..1
  const WaveformLoadResult({
    required this.signedL,
    required this.signedR,
    required this.rmsL,
    required this.rmsR,
    this.bandL,
    this.bandR,
  });
}

class WaveformCache {
  WaveformCache._();
  static final WaveformCache instance = WaveformCache._();

  Future<(List<double> left, List<double> right)> loadOrBuildStereoSigned({
    required String mediaPath,
    required String cacheDir,
    required String cacheKey,
    int? targetSamples,
    Duration? durationHint,
    WaveformProgressCallback? onProgress,
  }) async {
    final res = await loadOrBuildStereoVectors(
      mediaPath: mediaPath,
      cacheDir: cacheDir,
      cacheKey: cacheKey,
      targetSamples: targetSamples,
      durationHint: durationHint,
      onProgress: onProgress,
      enableFftwBands: false,
    );
    return (res.signedL, res.signedR);
  }

  Future<WaveformLoadResult> loadOrBuildStereoVectors({
    required String mediaPath,
    required String cacheDir,
    required String cacheKey,
    int? targetSamples,
    Duration? durationHint,
    WaveformProgressCallback? onProgress,
    bool enableFftwBands = true,
  }) async {
    ({File left, File right})? split;
    try {
      split = await _ensureSplitWavs(
        mediaPath: mediaPath,
        cacheDir: cacheDir,
        cacheKey: cacheKey,
        onProgress: onProgress,
      );
    } on FfmpegUnavailable {
      split = null;
      print('[CACHE] ffmpeg unavailable → fallback to JustWaveform');
    }

    List<double>? pcmL, pcmR;
    if (split != null) {
      try {
        pcmL = await _readWavPcm16MonoToF32(split.left.path);
        pcmR = await _readWavPcm16MonoToF32(split.right.path);
        print(
          '[CACHE] PCM split ok  pcmL=${pcmL.length}, pcmR=${pcmR.length}',
        );
      } catch (e) {
        print('[CACHE] PCM read failed → $e');
        pcmL = pcmR = null;
      }
    }

    List<double> signedL, signedR, rmsL, rmsR;
    List<double>? bandL, bandR;

    if (pcmL != null && pcmR != null && pcmL.isNotEmpty && pcmR.isNotEmpty) {
      final maxN = math.max(pcmL.length, pcmR.length);
      pcmL = _padTo(pcmL, maxN);
      pcmR = _padTo(pcmR, maxN);

      final n = maxN;
      final ts = (targetSamples ?? math.min(60000, n)).clamp(512, 300000);
      final hop = (n / ts).floor().clamp(1, n);
      final win = hop * 2;

      print('[CACHE] PCM n=$n ts=$ts hop=$hop win=$win');

      rmsL = _rmsSeries(pcmL, win, hop);
      rmsR = _rmsSeries(pcmR, win, hop);
      signedL = _meanSeries(pcmL, win, hop, keepSign: true);
      signedR = _meanSeries(pcmR, win, hop, keepSign: true);
      _normalizeEach(signedL, signedR);

      if (enableFftwBands) {
        try {
          final op = WaveformAnalyzerFftwOp();
          final series = await op.analyze(
            pcmLeft: pcmL,
            pcmRight: pcmR,
            sampleRate: 44100,
            options: const WaveformAnalyzerFftwOptions(
              fftSize: 2048,
              hopSize: 512,
              bands: 4,
              aWeighting: false,
            ),
          );
          if (series != null) {
            final weights = <double>[0.20, 0.45, 0.30, 0.05];
            bandL = op.flattenWeighted(series.left, weights);
            bandR = op.flattenWeighted(series.right, weights);
            if (bandL.length != ts) bandL = _resampleToLength(bandL, ts);
            if (bandR.length != ts) bandR = _resampleToLength(bandR, ts);
          }
        } catch (e) {
          print('[CACHE] FFTW bands failed: $e');
        }
      }
    } else {
      // --- JustWaveform fallback ---
      final wf = await _extractWaveform(
        mediaPath: mediaPath,
        cacheDir: cacheDir,
        cacheKey: cacheKey,
        onProgress: onProgress,
      );
      final ts = wf.length.clamp(512, 300000);
      final hop = (wf.length / ts).floor().clamp(1, wf.length);
      final win = hop * 2;
      print('[CACHE] JW fallback N=${wf.length}, ts=$ts hop=$hop win=$win');

      signedL = _buildSignedSamples(wf, ts);
      signedR = _buildSignedSamples(wf, ts);
      _normalizeEach(signedL, signedR);
      final rmsApprox = _rmsFromWaveform(wf, ts);
      rmsL = rmsApprox;
      rmsR = rmsApprox;
      bandL = null;
      bandR = null;
    }

    final visScale = WaveformTuning.I.signedVisualScale;
    for (int i = 0; i < signedL.length; i++) {
      signedL[i] = (signedL[i] * visScale).clamp(-1.0, 1.0);
      if (i < signedR.length) {
        signedR[i] = (signedR[i] * visScale).clamp(-1.0, 1.0);
      }
    }

    print(
      '[CACHE] signedL=${signedL.length}, signedR=${signedR.length}, '
      'rmsL=${rmsL.length}, rmsR=${rmsR.length}, '
      'bandL=${bandL?.length ?? 0}, bandR=${bandR?.length ?? 0}',
    );

    return WaveformLoadResult(
      signedL: signedL,
      signedR: signedR,
      rmsL: rmsL,
      rmsR: rmsR,
      bandL: bandL,
      bandR: bandR,
    );
  }

  // ---------- Internals ----------

  Future<({File left, File right})> _ensureSplitWavs({
    required String mediaPath,
    required String cacheDir,
    required String cacheKey,
    WaveformProgressCallback? onProgress,
  }) async {
    final dir = Directory(p.join(cacheDir, 'wav', cacheKey));
    if (!dir.existsSync()) dir.createSync(recursive: true);
    final l = File(p.join(dir.path, 'L.wav'));
    final r = File(p.join(dir.path, 'R.wav'));
    if (l.existsSync() && r.existsSync()) return (left: l, right: r);

    final ffmpegExe = _findBundledFfmpeg() ?? 'ffmpeg';
    try {
      final p1 = await Process.run(ffmpegExe, [
        '-y',
        '-i',
        mediaPath,
        '-ar',
        '44100',
        '-acodec',
        'pcm_s16le',
        '-af',
        'pan=mono|c0=FL',
        l.path,
      ]);
      if (p1.exitCode != 0) {
        throw FfmpegUnavailable('ffmpeg L split failed: ${p1.stderr}');
      }

      final p2 = await Process.run(ffmpegExe, [
        '-y',
        '-i',
        mediaPath,
        '-ar',
        '44100',
        '-acodec',
        'pcm_s16le',
        '-af',
        'pan=mono|c0=FR',
        r.path,
      ]);
      if (p2.exitCode != 0) {
        throw FfmpegUnavailable('ffmpeg R split failed: ${p2.stderr}');
      }

      print('[CACHE] ffmpeg split done L=${l.path} R=${r.path}');
      return (left: l, right: r);
    } on FfmpegUnavailable catch (e) {
      print('[CACHE] ffmpeg unavailable: $e');
      rethrow;
    } on ProcessException catch (e) {
      print('[CACHE] ffmpeg spawn blocked: $e');
      throw FfmpegUnavailable('spawn failed: $e');
    } catch (e) {
      print('[CACHE] ffmpeg unexpected: $e');
      throw FfmpegUnavailable('unexpected: $e');
    }
  }

  Future<Waveform> _extractWaveform({
    required String mediaPath,
    required String cacheDir,
    required String cacheKey,
    WaveformProgressCallback? onProgress,
  }) async {
    final dst = p.join(cacheDir, '$cacheKey.wave');
    Waveform? last;
    final stream = JustWaveform.extract(
      audioInFile: File(mediaPath),
      waveOutFile: File(dst),
    );

    await for (final prog in stream) {
      onProgress?.call(prog.progress);
      if (prog.waveform != null) last = prog.waveform;
    }

    if (last == null) {
      throw StateError('Waveform extraction ended without result.');
    }
    return last;
  }

  Future<List<double>> _readWavPcm16MonoToF32(String path) async {
    final f = File(path);
    final bytes = await f.readAsBytes();
    if (bytes.length < 44) throw Exception('invalid WAV header');
    final dataOffset = 44;
    final n = ((bytes.length - dataOffset) / 2).floor();
    final out = List<double>.filled(n, 0.0);
    for (int i = 0; i < n; i++) {
      final lo = bytes[dataOffset + i * 2];
      final hi = bytes[dataOffset + i * 2 + 1];
      int s = (hi << 8) | lo;
      if (s & 0x8000 != 0) s -= 0x10000;
      out[i] = (s / 32768.0).clamp(-1.0, 1.0);
    }
    return out;
  }

  List<double> _rmsSeries(List<double> x, int win, int hop) {
    final out = <double>[];
    int i = 0;
    while (i + win <= x.length) {
      double acc2 = 0;
      for (int k = 0; k < win; k++) {
        final v = x[i + k];
        acc2 += v * v;
      }
      out.add(math.sqrt(acc2 / win).clamp(0.0, 1.0));
      i += hop;
    }
    if (out.isEmpty) out.add(0.0);
    return out;
  }

  List<double> _meanSeries(
    List<double> x,
    int win,
    int hop, {
    bool keepSign = false,
  }) {
    final out = <double>[];
    int i = 0;
    while (i + win <= x.length) {
      double acc = 0;
      for (int k = 0; k < win; k++) {
        acc += x[i + k];
      }
      double m = (acc / win).clamp(-1.0, 1.0);
      if (!keepSign) m = m.abs();
      out.add(m);
      i += hop;
    }
    if (out.isEmpty) out.add(0.0);
    return out;
  }

  void _normalizeEach(List<double> a, List<double> b) {
    double maxA = 1e-9, maxB = 1e-9;
    for (final v in a) {
      final av = v.abs();
      if (av > maxA) maxA = av;
    }
    for (final v in b) {
      final av = v.abs();
      if (av > maxB) maxB = av;
    }
    if (maxA > 0) {
      for (int i = 0; i < a.length; i++) {
        a[i] = (a[i] / maxA).clamp(-1.0, 1.0);
      }
    }
    if (maxB > 0) {
      for (int i = 0; i < b.length; i++) {
        b[i] = (b[i] / maxB).clamp(-1.0, 1.0);
      }
    }
  }

  List<double> _resampleToLength(List<double> src, int n) {
    if (src.isEmpty || n <= 1) {
      return List<double>.filled(math.max(1, n), 0.0);
    }
    final out = List<double>.filled(n, 0.0);
    for (int i = 0; i < n; i++) {
      final t = i * (src.length - 1) / (n - 1);
      final i0 = t.floor();
      final i1 = math.min(i0 + 1, src.length - 1);
      final w = t - i0;
      out[i] = ((1 - w) * src[i0] + w * src[i1]).clamp(0.0, 1.0);
    }
    return out;
  }

  List<double> _padTo(List<double> s, int n) {
    if (s.length >= n) return s;
    return List<double>.from(s)..addAll(List<double>.filled(n - s.length, 0.0));
  }

  int _maxAbsWave(Waveform wf) {
    int maxAbs = 1;
    for (final v in wf.data) {
      final av = v.abs();
      if (av > maxAbs) maxAbs = av;
    }
    return maxAbs;
  }

  List<double> _rmsFromWaveform(Waveform wf, int targetSamples) {
    final N = wf.length;
    if (N <= 0) return const [];
    targetSamples = targetSamples.clamp(1, N);
    final hop = (N / targetSamples).floor().clamp(1, N);
    final win = hop * 2;
    final maxAbs = _maxAbsWave(wf).toDouble();
    final out = <double>[];
    int i = 0;
    while (i + win <= N) {
      double acc2 = 0;
      for (int k = 0; k < win; k++) {
        final s = wf.data[i + k] / maxAbs;
        acc2 += s * s;
      }
      out.add(math.sqrt(acc2 / win).clamp(0.0, 1.0));
      i += hop;
    }
    if (out.isEmpty) out.add(0.0);
    return out;
  }

  List<double> _buildSignedSamples(Waveform wf, int targetSamples) {
    final N = wf.length;
    if (N <= 0) return const [];
    targetSamples = targetSamples.clamp(1, N);
    final hop = (N / targetSamples).floor().clamp(1, N);
    final win = hop * 2;
    final maxAbs = _maxAbsWave(wf).toDouble();
    final out = <double>[];
    int i = 0;
    bool sign = true;
    while (i + win <= N) {
      double m = 0;
      for (int k = 0; k < win; k++) {
        final v = (wf.data[i + k] / maxAbs).abs();
        if (v > m) m = v;
      }
      out.add(sign ? m : -m);
      sign = !sign;
      i += hop;
    }
    if (out.isEmpty) out.add(0.0);
    return out;
  }
}

// lib/services/student_service.dart
// v1.05 | 2025-08-24 | 이름 부분일치 + 뒷자리4 정확일치, 예외/타임아웃 가드
import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../supabase/supabase_tables.dart';
import '../models/student.dart';

class StudentService {
  final SupabaseClient _client = Supabase.instance.client;

  /// DEV 모드: 직접 SELECT
  /// 운영(v1.05~): RPC 전환 예정 (find_student(name,last4))
  Future<Student?> findByNameAndLast4({
    required String name,
    required String last4,
    Duration timeout = const Duration(seconds: 10),
  }) async {
    final n = name.trim();
    final l4 = last4.trim();

    if (n.isEmpty || l4.length != 4) return null;

    try {
      final future = _client
          .from(SupabaseTables.students)
          .select()
          .ilike('name', '%$n%') // 부분 일치
          .eq('phone_last4', l4) // 정확 일치
          .limit(1);

      final res = await future.timeout(timeout);
      if (res.isEmpty) return null;
      return Student.fromMap(res.first);
    } on TimeoutException {
      return null;
    } catch (_) {
      return null;
    }
  }
}

// lib/screens/lesson/lesson_history_screen.dart
import 'package:flutter/material.dart';

class LessonHistoryScreen extends StatelessWidget {
  const LessonHistoryScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('지난 수업 복습')),
      body: const Center(child: Text('v1.08에서 본기능 구현 예정')),
    );
  }
}

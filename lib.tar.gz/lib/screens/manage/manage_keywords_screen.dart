// lib/screens/manage/manage_keywords_screen.dart
import 'package:flutter/material.dart';

class ManageKeywordsScreen extends StatelessWidget {
  const ManageKeywordsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('키워드 관리')),
      body: const Center(child: Text('키워드 관리 화면은 이후 업데이트에서 완성됩니다.')),
    );
  }
}

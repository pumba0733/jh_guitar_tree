// lib/routes/app_routes.dart
import 'package:flutter/material.dart';

// 로그인/홈
import '../screens/auth/login_screen.dart';
import '../screens/home/student_home_screen.dart';
import '../screens/home/teacher_home_screen.dart';
import '../screens/home/admin_home_screen.dart';

// 레슨
import '../screens/lesson/today_lesson_screen.dart';
import '../screens/lesson/lesson_history_screen.dart';
import '../screens/lesson/summary_result_screen.dart';

// 요약
import '../screens/summary/lesson_summary_screen.dart';

// 관리
import '../screens/manage/manage_students_screen.dart';
import '../screens/manage/manage_teachers_screen.dart';
import '../screens/manage/manage_keywords_screen.dart';

// 설정
import '../screens/settings/logs_screen.dart';
import '../screens/settings/export_screen.dart';
import '../screens/settings/import_screen.dart';
import '../screens/settings/change_password_screen.dart';

class AppRoutes {
  // 기본/인증
  static const String login = '/login';

  // 홈
  static const String studentHome = '/student_home';
  static const String teacherHome = '/teacher_home';
  static const String adminHome = '/admin_home';

  // 레슨
  static const String todayLesson = '/today_lesson';
  static const String lessonHistory = '/lesson_history';

  // 요약
  static const String lessonSummary = '/lesson_summary';
  static const String summaryResult = '/summary_result';

  // 관리
  static const String manageStudents = '/manage_students';
  static const String manageTeachers = '/manage_teachers';
  static const String manageKeywords = '/manage_keywords';

  // 설정
  static const String logs = '/logs';
  static const String export = '/export';
  static const String importData = '/import';
  static const String changePassword = '/change_password';

  static Map<String, WidgetBuilder> get routes => {
    // 기본/인증
    login: (_) => const LoginScreen(),

    // 홈
    studentHome: (_) => const StudentHomeScreen(),
    teacherHome: (_) => const TeacherHomeScreen(),
    adminHome: (_) => const AdminHomeScreen(),

    // 레슨
    todayLesson: (context) {
      final args = ModalRoute.of(context)?.settings.arguments;
      // 허용 형태: String(studentId) | {'studentId': '...', 'teacherId': '...'}
      String? studentId;
      String? teacherId;
      if (args is String) {
        studentId = args;
      } else if (args is Map) {
        if (args['studentId'] is String) studentId = args['studentId'];
        if (args['teacherId'] is String) teacherId = args['teacherId'];
      }
      if (studentId == null) {
        return const Scaffold(body: Center(child: Text('studentId가 필요합니다')));
      }
      return TodayLessonScreen(studentId: studentId!, teacherId: teacherId);
    },

    lessonHistory: (context) {
      final args = ModalRoute.of(context)?.settings.arguments;
      // 허용 형태: String(studentId) | {'studentId': '...', 'from': DateTime, 'to': DateTime}
      String? studentId;
      DateTime? from;
      DateTime? to;
      if (args is String) {
        studentId = args;
      } else if (args is Map) {
        if (args['studentId'] is String) studentId = args['studentId'];
        if (args['from'] is DateTime) from = args['from'];
        if (args['to'] is DateTime) to = args['to'];
      }
      if (studentId == null) {
        return const Scaffold(body: Center(child: Text('studentId가 필요합니다')));
      }
      return LessonHistoryScreen(studentId: studentId!, from: from, to: to);
    },

    // 요약
    lessonSummary: (_) => const LessonSummaryScreen(),
    summaryResult: (context) {
      final args = ModalRoute.of(context)?.settings.arguments;
      String? summaryId;
      if (args is String) {
        summaryId = args;
      } else if (args is Map && args['summaryId'] is String) {
        summaryId = args['summaryId'];
      }
      return SummaryResultScreen(summaryId: summaryId);
    },

    // 관리
    manageStudents: (_) => const ManageStudentsScreen(),
    manageTeachers: (_) => const ManageTeachersScreen(),
    manageKeywords: (_) => const ManageKeywordsScreen(),

    // 설정
    logs: (_) => const LogsScreen(),
    export: (_) => const ExportScreen(),
    importData: (_) => const ImportScreen(),
    changePassword: (_) => const ChangePasswordScreen(),
  };
}

// lib/screens/lesson/today_lesson_screen.dart
// v1.21 | 오늘 수업 화면(학생 지정) - SaveStatusIndicator(status: SaveStatus.*)로 수정
import 'package:flutter/material.dart';
import '../../services/lesson_service.dart';
import '../../ui/components/save_status_indicator.dart';

class TodayLessonScreen extends StatefulWidget {
  final String studentId;
  final String? teacherId;

  const TodayLessonScreen({super.key, required this.studentId, this.teacherId});

  @override
  State<TodayLessonScreen> createState() => _TodayLessonScreenState();
}

class _TodayLessonScreenState extends State<TodayLessonScreen> {
  // LessonService는 factory로 싱글톤 연결됨
  final LessonService _service = LessonService();

  final _subjectCtl = TextEditingController();
  final _memoCtl = TextEditingController();
  final _nextCtl = TextEditingController();

  bool _saving = false; // 내부 상태는 bool로 유지
  String? _lessonId;

  @override
  void initState() {
    super.initState();
    _ensureTodayRow();
  }

  Future<void> _ensureTodayRow() async {
    final today = DateTime.now();
    final d0 = DateTime(today.year, today.month, today.day);
    final dateStr = d0.toIso8601String().split('T').first; // YYYY-MM-DD

    // 오늘자 기존 레슨 조회
    final list = await _service.listByStudent(
      widget.studentId, // positional
      from: d0,
      to: d0,
      limit: 1,
    );

    Map<String, dynamic> row;
    if (list.isNotEmpty) {
      row = list.first;
    } else {
      row = await _service.upsert({
        'student_id': widget.studentId,
        if (widget.teacherId != null) 'teacher_id': widget.teacherId,
        'date': dateStr,
        'subject': '',
        'memo': '',
        'next_plan': '',
      });
    }

    _lessonId = row['id']?.toString();
    _subjectCtl.text = (row['subject'] ?? '').toString();
    _memoCtl.text = (row['memo'] ?? '').toString();
    _nextCtl.text = (row['next_plan'] ?? '').toString();

    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    if (_lessonId == null) return;
    setState(() => _saving = true);
    try {
      await _service.upsert({
        'id': _lessonId,
        'student_id': widget.studentId,
        if (widget.teacherId != null) 'teacher_id': widget.teacherId,
        'subject': _subjectCtl.text,
        'memo': _memoCtl.text,
        'next_plan': _nextCtl.text,
      });
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // SaveStatusIndicator 가 요구하는 enum으로 매핑
    final SaveStatus status = _saving ? SaveStatus.saving : SaveStatus.idle;

    return Scaffold(
      appBar: AppBar(title: const Text('오늘 수업')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _subjectCtl,
              decoration: const InputDecoration(labelText: '주제'),
              onChanged: (_) => _save(),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _memoCtl,
              decoration: const InputDecoration(labelText: '메모'),
              maxLines: 4,
              onChanged: (_) => _save(),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _nextCtl,
              decoration: const InputDecoration(labelText: '다음 계획'),
              onChanged: (_) => _save(),
            ),
            const SizedBox(height: 12),
            SaveStatusIndicator(status: status),
          ],
        ),
      ),
    );
  }
}

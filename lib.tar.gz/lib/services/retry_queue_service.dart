// lib/services/retry_queue_service.dart
// v1.21.2 자동 재시도 큐 — Hive 기반 (lesson_upsert, summary_upsert)
// - pendingCount 게터
// - enqueueTodayPatch(studentId, date, patch) 헬퍼
// - flushAll() 성공/실패 카운트 반환
// - start()/stop() 주기적 재시도
//
// 주의: Hive 초기화는 앱 전역에서 1회 수행하세요. (예: Hive.initFlutter())
// 이 프로젝트에선 필요한 시점에 openBox를 수행합니다.
import 'dart:async';
import 'dart:convert';
import 'package:hive/hive.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class RetryTask {
  final String id; // 고유키 (예: 'lesson:STUDENTID:2025-08-24')
  final String kind; // 'lesson_upsert' | 'summary_upsert'
  final Map<String, dynamic> payload;
  final int retries; // 시도 횟수
  final DateTime createdAt;

  RetryTask({
    required this.id,
    required this.kind,
    required this.payload,
    this.retries = 0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  RetryTask copyWith({int? retries}) => RetryTask(
    id: id,
    kind: kind,
    payload: payload,
    retries: retries ?? this.retries,
    createdAt: createdAt,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'kind': kind,
    'payload': payload,
    'retries': retries,
    'createdAt': createdAt.toIso8601String(),
  };

  static RetryTask fromMap(Map<String, dynamic> m) => RetryTask(
    id: m['id'] as String,
    kind: m['kind'] as String,
    payload: Map<String, dynamic>.from(m['payload'] as Map),
    retries: (m['retries'] as num?)?.toInt() ?? 0,
    createdAt:
        DateTime.tryParse(m['createdAt'] as String? ?? '') ?? DateTime.now(),
  );
}

class RetryQueueService {
  RetryQueueService._internal();
  static final RetryQueueService _i = RetryQueueService._internal();
  factory RetryQueueService() => _i;

  Timer? _timer;

  Future<Box> _box() => Hive.openBox('retry_queue_box');

  Future<int> get pendingCount async {
    final b = await _box();
    return b.length;
  }

  /// lesson_upsert 전용 헬퍼 (오늘 날짜 기준) — patch에는 subject/memo/next_plan/youtube_url/keywords 등 필드 포함
  Future<void> enqueueTodayPatch({
    required String studentId,
    required DateTime date,
    required Map<String, dynamic> patch,
  }) async {
    final keyDate = date.toIso8601String().split('T').first;
    final id = 'lesson:$studentId:$keyDate';
    final row = {'student_id': studentId, 'date': keyDate, ...patch};
    final task = RetryTask(
      id: id,
      kind: 'lesson_upsert',
      payload: {'row': row},
    );
    await enqueue(task);
  }

  Future<void> enqueue(RetryTask task) async {
    final b = await _box();
    await b.put(task.id, task.toMap());
  }

  Future<void> remove(String id) async {
    final b = await _box();
    await b.delete(id);
  }

  /// 모든 대기 작업 처리
  /// - Supabase 직접 호출(서비스 주입 없이)로 동작
  /// - return: (success, failure)
  Future<({int success, int failure})> flushAll() async {
    final b = await _box();
    final client = Supabase.instance.client;

    int ok = 0, fail = 0;
    final keys = b.keys.toList();
    for (final k in keys) {
      final raw = b.get(k);
      if (raw == null) continue;
      final task = RetryTask.fromMap(Map<String, dynamic>.from(raw as Map));

      final success = await _processTask(client, task);
      if (success) {
        ok++;
        await b.delete(k);
      } else {
        // 증가시켜 재시도 기회 부여 (최대 5회)
        final next = task.copyWith(retries: task.retries + 1);
        if (next.retries >= 5) {
          await b.delete(k);
        } else {
          await b.put(k, next.toMap());
        }
        fail++;
      }
    }
    return (success: ok, failure: fail);
  }

  Future<bool> _processTask(SupabaseClient client, RetryTask task) async {
    try {
      switch (task.kind) {
        case 'lesson_upsert':
          {
            final payload = task.payload;
            final row = Map<String, dynamic>.from(payload['row'] as Map);
            await client.from('lessons').upsert(row);
            return true;
          }
        case 'summary_upsert':
          {
            final payload = task.payload;
            final row = Map<String, dynamic>.from(payload['row'] as Map);
            await client.from('summaries').upsert(row);
            return true;
          }
        default:
          return false;
      }
    } catch (_) {
      return false;
    }
  }

  /// 주기적 재시도 시작 (기본 10초)
  void start({Duration interval = const Duration(seconds: 10)}) {
    _timer?.cancel();
    _timer = Timer.periodic(interval, (_) => flushAll());
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }
}

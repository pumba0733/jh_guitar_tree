// lib/services/teacher_service.dart
// v1.33.0 | 안전 패치:
// - 이메일 정규화(lowercase+trim) 일관 사용
// - syncCurrentAuthUserLink: p_is_admin 전달 제거(관리자 플래그 보호)
// - RPC 명 일치: sync_auth_user_id_by_email / upsert_teacher_min

import 'package:supabase_flutter/supabase_flutter.dart';
import '../supabase/supabase_tables.dart';
import '../models/teacher.dart';

class TeacherService {
  final SupabaseClient _client = Supabase.instance.client;

  // 이메일 정규화: lower + trim
  String _normEmail(String email) => email.trim().toLowerCase();

  Future<bool> existsByEmail(String email) async {
    final e = _normEmail(email);
    if (e.isEmpty) return false;
    try {
      final res = await _client
          .from(SupabaseTables.teachers)
          .select('id')
          .eq('email', e) // 서버는 lower(email) 유니크 인덱스 있음, 클라에서도 lower 고정
          .limit(1);
      return res is List && res.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<Teacher?> getByEmail(String email) async {
    final e = _normEmail(email);
    if (e.isEmpty) return null;
    final res = await _client
        .from(SupabaseTables.teachers)
        .select('id, name, email, is_admin, auth_user_id')
        .eq('email', e)
        .limit(1);
    if (res is List && res.isNotEmpty) {
      return Teacher.fromMap(Map<String, dynamic>.from(res.first));
    }
    return null;
  }

  /// RPC: teachers.auth_user_id를 현재 auth.uid()로 동기화
  Future<void> syncAuthUserIdByEmail(String email) async {
    final e = _normEmail(email);
    await _client.rpc('sync_auth_user_id_by_email', params: {'p_email': e});
  }

  /// 로그인 직후 연동:
  /// 1) upsert_teacher_min: 최소 행 보장 (⚠️ p_is_admin 전달하지 않음)
  /// 2) sync_auth_user_id_by_email: auth_user_id, last_login 갱신
  Future<void> syncCurrentAuthUserLink() async {
    final u = _client.auth.currentUser;
    if (u == null) return;
    final email = _normEmail(u.email ?? '');
    if (email.isEmpty) return;

    // 1) 없으면 생성/있으면 이름만 보정. 관리자 플래그는 서버가 유지.
    await _client.rpc(
      'upsert_teacher_min',
      params: {
        'p_email': email,
        'p_name': email.split('@').first,
        // 'p_is_admin' 전달 금지: 실수로 관리자 플래그를 덮지 않기 위함
      },
    );

    // 2) auth_user_id 링크 + 마지막 로그인 갱신
    await syncAuthUserIdByEmail(email);
  }

  /// 관리자(또는 서버키)만 isAdmin이 반영됨(서버 SQL에서 가드)
  Future<bool> registerTeacher({
    required String name,
    required String email,
    required String password,
    bool isAdmin = false,
  }) async {
    final e = _normEmail(email);
    final signUp = await _client.auth.signUp(
      email: e,
      password: password,
      data: {'role': isAdmin ? 'admin' : 'teacher'},
    );
    if (signUp.user == null) return false;

    await _client.rpc(
      'upsert_teacher_min',
      params: {
        'p_email': e,
        'p_name': name.trim().isEmpty ? e.split('@').first : name.trim(),
        'p_is_admin': isAdmin, // 서버 함수가 비관리자 호출이면 무시
      },
    );
    await syncAuthUserIdByEmail(e);
    return true;
  }
}

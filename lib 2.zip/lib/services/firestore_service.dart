// 📄 lib/services/firestore_service.dart

class FirestoreService {
  // Firebase Firestore 연동용 클래스 - 실제 구현은 추후 진행
}

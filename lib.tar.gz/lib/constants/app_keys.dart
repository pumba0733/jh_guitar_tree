// lib/constants/app_keys.dart
class AppKeys {
  // Reserved for local cache keys / settings.
  static const lastSummaryStudentId = 'last_summary_student_id';
}

// lib/services/backup_service.dart
// v1.21.2 | JSON 백업/복원 — 커리큘럼 포함 옵션 추가
import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/lesson_service.dart';
import '../services/summary_service.dart';

class BackupService {
  final LessonService _lesson = LessonService();
  final SummaryService _summary = SummaryService();
  final SupabaseClient _client = Supabase.instance.client;

  /// 학생 단위 백업 JSON 구성 (Map 기반)
  /// includeCurriculum=true 시 curriculum_nodes/assignments도 포함(가능한 경우)
  Future<Map<String, dynamic>> buildStudentBackup({
    required String studentId,
    bool includeLessons = true,
    bool includeSummaries = true,
    bool includeCurriculum = false,
  }) async {
    // 학생 정보
    final s = await _client
        .from('students')
        .select()
        .eq('id', studentId)
        .maybeSingle();

    // 레슨
    final lessons = includeLessons
        ? await _client
              .from('lessons')
              .select()
              .eq('student_id', studentId)
              .order('date', ascending: true)
        : const [];

    // 요약
    final summaries = includeSummaries
        ? await _client
              .from('summaries')
              .select()
              .eq('student_id', studentId)
              .order('created_at', ascending: true)
        : const [];

    // 커리큘럼 (테이블 없을 수 있어 try/catch)
    List nodes = const [];
    List assigns = const [];
    if (includeCurriculum) {
      try {
        assigns = await _client
            .from('curriculum_assignments')
            .select()
            .eq('student_id', studentId);
        final nodeIds = (assigns as List)
            .map((e) => (e as Map)['curriculum_node_id'])
            .where((e) => e != null)
            .toSet()
            .toList();
        if (nodeIds.isNotEmpty) {
          nodes = await _client
              .from('curriculum_nodes')
              .select()
              .in_('id', nodeIds);
        }
      } catch (_) {
        // 무시 (미구축 환경)
      }
    }

    return {
      'student': s,
      'lessons': lessons,
      'summaries': summaries,
      if (includeCurriculum) 'curriculum_nodes': nodes,
      if (includeCurriculum) 'curriculum_assignments': assigns,
    };
  }

  /// 백업 JSON 문자열을 파싱
  Map<String, dynamic> parseBackupJson(String jsonString) {
    final parsed = jsonDecode(jsonString);
    if (parsed is! Map<String, dynamic>) {
      throw FormatException('백업 파일 형식이 올바르지 않습니다.');
    }
    return parsed;
  }

  /// 복원 (간단 upsert) — 학생/레슨/요약/커리큘럼
  Future<void> restoreBackup(Map<String, dynamic> backup) async {
    // 학생
    final student = backup['student'];
    if (student is Map<String, dynamic>) {
      await _client.from('students').upsert(student);
    }

    // 레슨
    final lessons = backup['lessons'];
    if (lessons is List) {
      for (final raw in lessons) {
        if (raw is Map<String, dynamic>) {
          await _client.from('lessons').upsert(raw);
        }
      }
    }

    // 요약
    final summaries = backup['summaries'];
    if (summaries is List) {
      for (final raw in summaries) {
        if (raw is Map<String, dynamic>) {
          await _client.from('summaries').upsert(raw);
        }
      }
    }

    // 커리큘럼
    final nodes = backup['curriculum_nodes'];
    if (nodes is List) {
      for (final raw in nodes) {
        if (raw is Map<String, dynamic>) {
          await _client.from('curriculum_nodes').upsert(raw);
        }
      }
    }
    final assigns = backup['curriculum_assignments'];
    if (assigns is List) {
      for (final raw in assigns) {
        if (raw is Map<String, dynamic>) {
          await _client.from('curriculum_assignments').upsert(raw);
        }
      }
    }
  }
}

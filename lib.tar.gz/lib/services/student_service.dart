// lib/services/student_service.dart
// v1.31.1 | 학생 CRUD + 검색 + find_student RPC + 이름 맵 조회 (체이닝 타입 수정/경고 제거)
import 'package:supabase_flutter/supabase_flutter.dart';
import '../supabase/supabase_tables.dart';
import '../models/student.dart';

class StudentService {
  final SupabaseClient _client = Supabase.instance.client;

  // ---------- 단건 조회 (RPC 우선) ----------
  Future<Student?> findByNameAndLast4({
    required String name,
    required String last4,
  }) async {
    final n = name.trim();
    final l4 = last4.trim();
    if (n.isEmpty || l4.length != 4) return null;

    // Prefer RPC (SQL 함수: find_student)
    final rpcRes = await _client.rpc(
      'find_student',
      params: {'p_name': n, 'p_last4': l4},
    );

    // RPC는 Map 또는 List 한 건 형태로 반환될 수 있음
    if (rpcRes is Map && rpcRes.isNotEmpty) {
      return Student.fromMap(Map<String, dynamic>.from(rpcRes));
    }
    if (rpcRes is List && rpcRes.isNotEmpty) {
      return Student.fromMap(Map<String, dynamic>.from(rpcRes.first));
    }

    // Fallback: 직접 조회 (dev/staging에서 RPC 미배포 대비)
    final res = await _client
        .from(SupabaseTables.students)
        .select()
        .eq('phone_last4', l4)
        .ilike('name', '%$n%') // ← 필터 빌더 단계에서 사용 (OK)
        .limit(1);

    final list = (res as List);
    if (list.isNotEmpty) {
      return Student.fromMap(Map<String, dynamic>.from(list.first));
    }
    return null;
  }

  // ---------- 목록 조회 ----------
  Future<List<Student>> list({
    String? query, // 이름 검색
    int limit = 100,
    int offset = 0,
    String orderBy = 'created_at',
    bool ascending = false,
  }) async {
    // 필터 단계에서 ilike 적용 -> 그 다음에 order/range 적용 (타입 안전)
    var filter = _client.from(SupabaseTables.students).select();

    final q = (query ?? '').trim();
    if (q.isNotEmpty) {
      filter = filter.ilike('name', '%$q%');
    }

    final res = await filter
        .order(orderBy, ascending: ascending) // transform builder는 여기에서
        .range(offset, offset + limit - 1);

    final list = (res as List);
    return list
        .map((e) => Student.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  // ---------- 생성 ----------
  Future<Student> create({
    required String name,
    String phoneLast4 = '',
    String? teacherId,
  }) async {
    final payload = {
      'name': name.trim(),
      'phone_last4': phoneLast4.trim(),
      if ((teacherId ?? '').trim().isNotEmpty) 'teacher_id': teacherId,
    };
    final res = await _client
        .from(SupabaseTables.students)
        .insert(payload)
        .select()
        .single();
    return Student.fromMap(Map<String, dynamic>.from(res));
  }

  // ---------- 수정 ----------
  Future<Student> update({
    required String id,
    String? name,
    String? phoneLast4,
    String? teacherId,
  }) async {
    final patch = <String, dynamic>{};
    if (name != null) patch['name'] = name.trim();
    if (phoneLast4 != null) patch['phone_last4'] = phoneLast4.trim();
    if (teacherId != null) patch['teacher_id'] = teacherId;

    final res = await _client
        .from(SupabaseTables.students)
        .update(patch)
        .eq('id', id)
        .select()
        .single();
    return Student.fromMap(Map<String, dynamic>.from(res));
  }

  // ---------- 삭제 ----------
  Future<void> remove(String id) async {
    await _client.from(SupabaseTables.students).delete().eq('id', id);
  }

  // ---------- 이름 맵 조회 (id -> name) ----------
  Future<Map<String, String>> fetchNamesByIds(Iterable<String> ids) async {
    final list = ids.where((e) => e.trim().isNotEmpty).toSet().toList();
    if (list.isEmpty) return {};
    final res = await _client
        .from(SupabaseTables.students)
        .select('id, name')
        .inFilter('id', list);

    final rows = (res as List);
    final map = <String, String>{};
    for (final row in rows) {
      final m = Map<String, dynamic>.from(row);
      map[m['id'] as String] = m['name'] as String;
    }
    return map;
  }
}

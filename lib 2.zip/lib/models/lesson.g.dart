// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lesson.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class LessonAdapter extends TypeAdapter<Lesson> {
  @override
  final int typeId = 1;

  @override
  Lesson read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Lesson(
      studentId: fields[0] as String,
      date: fields[1] as String,
      subject: fields[2] as String,
      keywords: (fields[3] as List).cast<String>(),
      memo: fields[4] as String,
      nextPlan: fields[5] as String,
      audioPaths: (fields[6] as List).cast<String>(),
      youtubeUrl: fields[7] as String,
    );
  }

  @override
  void write(BinaryWriter writer, Lesson obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.studentId)
      ..writeByte(1)
      ..write(obj.date)
      ..writeByte(2)
      ..write(obj.subject)
      ..writeByte(3)
      ..write(obj.keywords)
      ..writeByte(4)
      ..write(obj.memo)
      ..writeByte(5)
      ..write(obj.nextPlan)
      ..writeByte(6)
      ..write(obj.audioPaths)
      ..writeByte(7)
      ..write(obj.youtubeUrl);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is LessonAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

// lib/screens/manage/manage_teachers_screen.dart
import 'package:flutter/material.dart';

class ManageTeachersScreen extends StatelessWidget {
  const ManageTeachersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('강사 관리')),
      body: const Center(child: Text('강사 관리 화면은 이후 업데이트에서 완성됩니다.')),
    );
  }
}

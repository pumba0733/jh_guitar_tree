// lib/services/supabase_service.dart
// v1.05 | 2025-08-24 | 공용 SupabaseClient 단일 진입점 + 세션 헬퍼
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  SupabaseService._();

  /// 단일 클라이언트 (Supabase.initialize 이후 사용)
  static final SupabaseClient client = Supabase.instance.client;

  /// 현재 세션/유저 헬퍼
  static Session? get currentSession => client.auth.currentSession;
  static User? get currentUser => client.auth.currentUser;

  /// 간단 핑(연결 문제 탐지용)
  static Future<bool> ping() async {
    try {
      // 매우 가벼운 RPC 또는 from().select() 한 줄도 가능하지만
      // 여기선 auth 상태만 확인
      await client.auth.refreshSession();
      return true;
    } catch (_) {
      return false;
    }
  }
}

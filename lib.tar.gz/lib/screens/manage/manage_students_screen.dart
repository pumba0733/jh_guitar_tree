// lib/screens/manage/manage_students_screen.dart
import 'package:flutter/material.dart';

class ManageStudentsScreen extends StatelessWidget {
  const ManageStudentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('학생 관리')),
      body: const Center(child: Text('학생 관리 화면은 이후 업데이트에서 완성됩니다.')),
    );
  }
}
